# Sean Paul Hoarding Bug

**Replaces the Hoarding Bug noises with Sean Paul noises!**

## What sounds will be replaced?

Hoarding Bug:
- Chitter1
- Chitter2
- Chitter3
- Fly

## Installation

1. Install BepInEx, Clementinise-CustomSounds and LCSoundTool

2. Download the Sean Paul mod files and put them in your "BepInEx\plugins" folder

3. Listen to Sean Paul making weird noises down the hallway :D